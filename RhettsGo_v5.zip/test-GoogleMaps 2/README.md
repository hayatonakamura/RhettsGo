# Google-Maps-Direction
Google Maps Direction Include Auto Complete Address Google Maps


This is Google Maps Direction And Autocomplete place using Google Maps Place API IOS SDK With Swift

#How to install

1. Clone this repo
2. Open directory on terminal
3. run pod install (this will download Google Maps SDK iOS)
4. run the workspace

#Screenshoot
![simulator screen shot feb 19 2017 12 38 15 pm](https://cloud.githubusercontent.com/assets/1490342/23099717/4f84d8b0-f6a0-11e6-832e-146d7951a75e.png)
-----------------
![simulator screen shot feb 19 2017 12 38 18 pm](https://cloud.githubusercontent.com/assets/1490342/23099718/4f851b72-f6a0-11e6-84f2-b43e01707d25.png)




