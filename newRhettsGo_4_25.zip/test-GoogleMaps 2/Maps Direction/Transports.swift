//
//  Transports.swift
//  MapsDirection
//
//  Created by Hayato Nakamura on 2018/04/24.
//  Copyright © 2018 balitax. All rights reserved.
//

import Foundation
import UIKit

class Transports: UIViewController{
    
    //first input argument: ETA label
    //second input argument: details label
    //third input argument: origin coordinates as a string
    //fourh input argument: destination coordinates as a string
    //This is true for every function: getTrainData, getBusData, getWalkingData
    
    func getTrainData(biglabel: UILabel, detailedlabel: UILabel, origin: String, destination: String, completionHandler: @escaping ([String: Any]) -> ()){
        
        let jsonURLString = "https://maps.googleapis.com/maps/api/directions/json?"
        let key = "AIzaSyAYQYjp_C4gySyTcGvSlV2VgQu8gz6KTzE"
        
        var results: [String] = []
        let urlstring = jsonURLString + "origin=" + origin + "&destination=" + destination + "&key=" + key + "&mode=transit&transit_mode=rail"
        let urlrequest = URLRequest(url: URL(string: urlstring)!)
        let config = URLSessionConfiguration.default
        let sessions = URLSession(configuration: config)
        
        let task = sessions.dataTask(with: urlrequest) { (data, response, error) in
            guard error == nil else {
                print("error getting data")
                print(error!)
                return
            }
            guard let responseData = data else {
                print("error, did not receive data")
                return
            }
            do {
                if let json = try JSONSerialization.jsonObject(with: responseData, options: []) as? [String: Any]{
                    if let routes = json["routes"] as? [[String: Any]] {
                        ////                    print(routes)
                        for rout in routes {
                            if let legs = rout["legs"] as? [[String: Any]]{
                                for leg in legs{
                                    var ETA = ""
                                    if let ETAstruct = leg["arrival_time"] as? [String: Any]{
                                        if let ETA = ETAstruct["text"]{
                                            biglabel.text = ETA as? String //set text for ETA label
                                        }
                                    }
                                    
                                    
                                    
                                    //                                    if let duration = leg["duration"] as? [String: Any]{
                                    //                                        //                                        print("Time it will take: ")
                                    //                                        //                                        print(duration["text"])
                                    //                                        let temp = duration["text"] as? String
                                    //
                                    //                                        results.append(temp!)
                                    //                                    }
                                    if let steps = leg["steps"] as? [[String: Any]]{
                                        //                                        print(steps)
                                        for step in steps{
                                            
                                            //                                            print("Instruction: ")
                                            //                                            print(step["html_instructions"])
                                            let transmode = step["travel_mode"] as? String
                                            var temp = "" as? String
                                            if  transmode == "TRANSIT"{
                                                
                                                //print(step)
                                                let details = step["transit_details"] as? [String: Any]
                                                let linedetails = details!["line"] as? [String: Any]
                                                let arrivaldetails = details!["arrival_stop"] as? [String: Any]
                                                let arrival_stop = arrivaldetails!["name"] as? String
                                                let trainname = linedetails!["name"] as? String
                                                let head = details!["headsign"] as? String
                                                let temp = "Take: " + trainname! + " towards " + head!
                                                //temp = temp2 + " and get off at " + arrival_stop!
                                                results.append(temp)
                                                results.append(arrival_stop!)
                                                
                                            }
                                            else {
                                                temp = step["html_instructions"] as? String
                                                let index = temp?.index((temp?.startIndex)!, offsetBy: 8)
                                                let mySubstring = temp?.suffix(from: index!) // playground
                                                let myString = String(describing: mySubstring) as String!
                                                //                                                print("Sup")
                                                //                                                print(myString)
                                                var yo: String!
                                                yo = myString
                                                results.append(yo!)
                                            }
                                            
                                        }
                                    }
                                    
                                    
                                }
                            }
                        }
                    }
                    var textdetails: String
                    textdetails = results[1] + "\nPick up at: " + results[0] + "\nGet off at: " + results[2]
                    print(textdetails)
                    detailedlabel.text = textdetails as! String
                    //
                    //                    for i in results{
                    //                        print(i)
                    //                    }
                }
                
            }
            catch {
                print("Error, could not configure data")
            }
            
            
            
        }
        task.resume()
    }
    
    
    
    func getBusData(biglabel: UILabel, detailedlabel: UILabel, origin: String, destination: String, completionHandler: @escaping ([String: Any]) -> ()){
        let jsonURLString = "https://maps.googleapis.com/maps/api/directions/json?"
        let key = "AIzaSyAYQYjp_C4gySyTcGvSlV2VgQu8gz6KTzE"
        let urlstring = jsonURLString + "origin=" + origin + "&destination=" + destination + "&key=" + key + "&mode=transit&transit_mode=bus"
        
        
        let urlrequest = URLRequest(url: URL(string: urlstring)!)
        
        
        let config = URLSessionConfiguration.default
        let sessions = URLSession(configuration: config)
        
        var results: [String] = []
        let task = sessions.dataTask(with: urlrequest) { (data, response, error) in
            guard error == nil else {
                print("error getting data")
                print(error!)
                return
            }
            guard let responseData = data else {
                print("error, did not receive data")
                return
            }
            do {
                if let json = try JSONSerialization.jsonObject(with: responseData, options: []) as? [String: Any]{
                    // print(json)
                    if let routes = json["routes"] as? [[String: Any]] {
                        //                    print(routes)
                        for rout in routes {
                            if let legs = rout["legs"] as? [[String: Any]]{
                                for leg in legs{
                                    var ETA = ""
                                    if let ETAstruct = leg["arrival_time"] as? [String: Any]{
                                        if let ETA = ETAstruct["text"]{
                                            biglabel.text = ETA as? String //set text for ETA label
                                        }
                                    }
                                    
                                    //
                                    //                                    if let duration = leg["duration"] as? [String: Any]{
                                    //                                        let temp = duration["text"] as? String
                                    //                                        results.append(temp!)
                                    //                                    }
                                    //                                    print("sup")
                                    if let steps = leg["steps"] as? [[String: Any]]{
                                        //                                        print(steps)
                                        for step in steps{
                                            let transmode = step["travel_mode"] as? String
                                            var temp = "" as? String
                                            if  transmode == "TRANSIT"{
                                                let details = step["transit_details"] as? [String: Any]
                                                let bustitle = details!["headsign"] as? String
                                                let linedetails = details!["line"] as? [String: Any]
                                                let busnumber = linedetails!["short_name"] as? String
                                                let instruction = step["html_instructions"] as? String
                                                let temp2 = "Take: #" + busnumber! + " " + bustitle!
                                                results.append(temp2)
                                                let arrivalstopdetails = details!["arrival_stop"] as? [String: Any]
                                                let destinationstop = arrivalstopdetails!["name"] as? String
                                                let departurestopdetails = details!["departure_stop"] as? [String: Any]
                                                let departurestop = departurestopdetails!["name"] as? String
                                                let temp3 = "Pick up at: " + departurestop!
                                                results.append(temp3)
                                                let temp4 = "Get off at: " + destinationstop!
                                                results.append(temp4)
                                                
                                                //                                                temp = temp2 + busnumber! + " " + bustitle!
                                            }
                                            else {
                                                //                                                temp = step["html_instructions"] as? String
                                            }
                                            //                                            results.append(temp!)
                                        }
                                    }
                                }
                            }
                        }
                        
                    }
                }
                var texts = ""
                for i in results{
                    texts = texts + i + "\n"
                }
                detailedlabel.text = texts
            }
            catch {
                print("Error, could not configure data")
            }
            
        }
        task.resume()
        
        
        
        
        
    }
    
    func getWalkingData(biglabel: UILabel, detailedlabel: UILabel, origin: String, destination: String, completionHandler: @escaping ([String: Any]) -> ()){
        
        var results: [String] = []
        let jsonURLString = "https://maps.googleapis.com/maps/api/directions/json?"
        let key = "AIzaSyAYQYjp_C4gySyTcGvSlV2VgQu8gz6KTzE"
        let urlstring = jsonURLString + "origin=" + origin + "&destination=" + destination + "&key=" + key + "&mode=walking"
        let urlrequest = URLRequest(url: URL(string: urlstring)!)
        let config = URLSessionConfiguration.default
        let sessions = URLSession(configuration: config)
        
        let task = sessions.dataTask(with: urlrequest) { (data, response, error) in
            guard error == nil else {
                print("error getting data")
                print(error!)
                return
            }
            guard let responseData = data else {
                print("error, did not receive data")
                return
            }
            do {
                if let json = try JSONSerialization.jsonObject(with: responseData, options: []) as? [String: Any]{
                    if let routes = json["routes"] as? [[String: Any]] {
                        //print(routes)
                        for rout in routes {
                            if let legs = rout["legs"] as? [[String: Any]]{
                                for leg in legs{
                                    if let timedetails = leg["duration"] as? [String: Any]{
                                        let time = timedetails["text"] as! String
                                        print("time:")
                                        print(time)
                                        let subtime = String(describing: time.prefix(2)) as! String
                                        print("subtime:")
                                        print(subtime)
                                        let duration = Int(subtime)
                                        print("duration: ")
                                         print(duration)
                                        var date = NSDate()
                                        var str = String(describing
                                            : date)
                                        let start = str.index(str.startIndex, offsetBy: 11)
                                        let end = str.index(str.endIndex, offsetBy: -9)
                                        let range = start..<end
                                        
                                        let mySubstring = str[range]
                                        let myString = String(mySubstring)
                                        
                                        let subHour = String(myString.prefix(2))
                                        print("subhour:")
                                                print(subHour)
                                        
                                        let subminutes = String(myString.suffix(2))
                                        
                                        var hour: Int = Int(subHour)!
                                        var min: Int = Int(subminutes)!
                                        
                                        hour = hour - 4
                                        if (min + duration! > 60){
                                            hour=hour+1
                                            min = min+duration! - 60
                                        }
                                        else{
                                            min = min + duration!
                                        }
                                        var pmoram=""
                                        if (hour > 12){
                                            hour = hour - 12
                                            pmoram = "pm"
                                        }
                                        else {
                                            pmoram="am"
                                        }
                                        
                                        let totaltime = String(hour) + ":" + String(min) + pmoram
                                        biglabel.text = totaltime //set text for ETA label
                                    }
                                    if let distancedetails = leg["distance"] as? [String: Any]{
                                        let distance = distancedetails["text"] as? String
                                        let distancetext = "Walking distance: " + distance!
                                        results.append(distancetext)
                                    }
                                    if let steps = leg["steps"] as? [[String: Any]]{
                                        for step in steps{
                                            let temp = step["html_instructions"] as? String
                                            results.append(temp!)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                let texts = results[0] + "\n" + "Total # of streets: " + String(results.count-1)
                detailedlabel.text = texts
                //                print(results.count)
            }
            catch{
                print("could not configure data")
            }
        }
        task.resume()
        
    }
    
    
    //returns a string which is the URL to create a deeplink for Google Maps
    //choice == bus , return BUS url
    //choice == train , return Train Url
    
    
    func getgoogleURL(choice: String, origin: String, destination: String) -> String{
        let str = "comgooglemaps://?" + "saddr=" + origin + "&daddr=" + destination + "&directionsmode=" //transit
        let res: String
        if (choice == "bus" || choice == "train"){
            res = str + "transit" + "&transitmode=bus"
        }
        else {
            res = str + "walking"
        }
        return res
        
    }
    
    
    
    
    
    
    
}
